package com.testsigma.addons.util;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ResponseData {
    String responseString;
    String value;
}
